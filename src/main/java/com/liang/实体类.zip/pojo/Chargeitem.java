package com.liang.pojo;

import lombok.Data;

@Data
public class Chargeitem {
    private Integer id;
    private String operator;
    private String model;
    private String location;
    private String status;
}
