package com.liang.pojo;

import lombok.Data;

@Data
public class Balance {
    private Integer id;
    private Integer userId;
    private Float balance;

}
